import { Injectable } from '@angular/core';
import {Assembling} from "../common/bean/assembling"

@Injectable()
export class AssemblingService{
  updateassemblingInfo(data:Assembling,datainfo:any){
    data.assemblyKey = datainfo.assemblyKey;
    data.lackKeyCount = datainfo.lackKeyCount;
    data.language = datainfo.language;
    data.timeConsume = datainfo.timeConsume;
    data.type = datainfo.type;
    
    
  }
 updateheadInfo(data: Assembling, datainfo: any, type: number) {
        if (type == 1) {
            data.keycaps[0].language = datainfo[0].language;
            data.keycaps[0].color = datainfo[0].color;
            data.keycaps[0].machineType = datainfo[0].machineType;
            data.keycaps[0].SN = datainfo[0].SN;
            data.keycaps[0].station = datainfo[0].station;
            data.keycaps[0].type = datainfo[0].type;
        } else {
            data.keycaps[1].language = datainfo[1].language;
            data.keycaps[1].color = datainfo[1].color;
            data.keycaps[1].machineType = datainfo[1].machineType;
            data.keycaps[1].SN = datainfo[1].SN;
            data.keycaps[1].station = datainfo[1].station;
            data.keycaps[1].type = datainfo[1].type;
        }
    } 
    productdetail(data: Assembling,datainfo:any){
     
        if(datainfo.code==="A"){
            datainfo.code="A工位";
            data.productdetail.codeStation="A工位";            
            data.productdetail.APCBSN=datainfo.PCBSN;
            data.productdetail.ATraySN=datainfo.TraySN;
        }else{
            data.productdetail.codeStation="B工位";
            datainfo.code="B工位"
            data.productdetail.BPCBSN=datainfo.PCBSN;
            data.productdetail.BTraySN=datainfo.TraySN;

        }
        data.productdetail.jobnumber=datainfo.jobnumber;
      
        data.productdetail.type=datainfo.type;
        data.detailproduct.push( datainfo);

    } 
  
}