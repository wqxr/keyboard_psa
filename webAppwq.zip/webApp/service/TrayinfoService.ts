import { Injectable } from '@angular/core';
import {Trayinfo} from "../common/bean/trayinfo"

@Injectable()
export class TrayinfoService{
  updatetrayInfo(data:Trayinfo,datainfo:any){
     
  }
}