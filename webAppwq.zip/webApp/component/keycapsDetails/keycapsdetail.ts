import { Component,NgZone,Input } from '@angular/core';
import * as _ from 'lodash';
import { Observable, Subscription } from 'rxjs';
import { Assembling } from '../../common/bean/assembling';



@Component({
  selector: 'keycapsdetail',
  templateUrl:"./webApp/component/keycapsDetails/keycapsdetail.html"
})
export class KeycapDetailComponent {
  private _ngZone: NgZone
  private title:String;
  @Input()
  private assembling: Assembling;
  @Input()
  private configinfos:{};
  constructor( _ngZone: NgZone){
    this._ngZone = _ngZone;
    this.title = 'IAStudio';
  }
  
}