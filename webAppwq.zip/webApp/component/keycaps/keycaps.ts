import { Component,NgZone,Input } from '@angular/core';
import * as _ from 'lodash';
import { Observable, Subscription } from 'rxjs';
import { Assembling } from '../../common/bean/assembling';
import { workModel } from '../../common/bean/workmodel';
import { IPCService } from '../../common/service/ipc.service';
import { MSG_TYPE } from "../../common/bean/msgType";






@Component({
  selector: 'keycaps',
  templateUrl:"./webApp/component/keycaps/keycaps.html"
})


export class KeycapsComponent {
  
  private _ngZone: NgZone
  private title:String;
  private ipcService:IPCService;
  
  @Input()
  public assembling: Assembling;
  @Input()
  private logs:{time:number,loginfo:string}[];
  private iscongigshow:boolean=true;
  private checknumber:number;
  private startclass:boolean=false;
  private workmodel:workModel;
  private config:{
       CCD:boolean;
       scanCode:boolean;
       dataUpload:boolean;
       space:boolean;
       enableStationA:boolean;
       enableStationB:boolean;
       showflowin:boolean;
       emptyrun:boolean;//空炮
       enter:boolean;
       up:boolean;
       down:boolean;
    }
  private key:{
    enter:string;
    up:string
    down:string;
    space:string;
  }


  private keyData : any[];

  constructor( _ngZone: NgZone,ipcService:IPCService){
    this._ngZone = _ngZone;
    this.title = 'IAStudio';
    this.ipcService=ipcService;
    this.workmodel=new workModel();
    this.checknumber=0;
    console.log(_.isString(this.title));
    this.keyData =[];
    this.config={
      CCD:false,
      scanCode:false,
      dataUpload:false,
      space:false,
      enableStationA:false,
      enableStationB:false,
      showflowin:false,
      emptyrun:false,
      enter:false,
      up:false,
      down:false,
    }
    this.key={
      enter:"",
      up:"",
      down:"",
      space:"",

    }
  }


readconfig(data:any){
  if(data.CCD===1){
    this.config.CCD=true;
  } 
  if(data.scanCode==1){
    this.config.scanCode=true;
  }
   if(data.dataUpload==1){
    this.config.dataUpload=true;
  }
  if(data.space==0){
    this.config.space=true;
  } 
  if(data.enableStationA==1){
    this.config.enableStationA=true;
  }
   if(data.enableStationB==1){
    this.config.enableStationB=true;
  }
   if(data.showflowin==1){
    this.config.showflowin=true
  }
   if(data.emptyrun==1){
    this.config.emptyrun=true;
  }
}


  changedata() {  
    if (this.config.CCD == true) {
      this.workmodel.CCD = 1;
    } else {
      this.workmodel.CCD = 0;
    }
    if (this.config.dataUpload == true) {
      this.workmodel.dataUpload = 1;
    } else {    
      this.workmodel.dataUpload = 0;
    }
    if (this.config.scanCode == true) {
      this.workmodel.scanCode = 1;
    } else {
      this.workmodel.scanCode = 0;
    }
    if (this.config.space == true) {
      this.workmodel.space = 1;
      this.key.space="space";

    } else {
      this.key.space="";
      this.workmodel.space = 0;
    }
    if (this.config.enableStationA == true) {
      this.workmodel.enableStationA = 1;
    } else {
      this.workmodel.enableStationA = 0;
    }
    if (this.config.enableStationB == true) {
      this.workmodel.enableStationB = 1;
    } else {
      this.workmodel.enableStationB = 0;
    }

    if (this.config.showflowin == true) {
      this.workmodel.showflowin = 1;
      this.config.scanCode = true;
      this.workmodel.scanCode=1;

    } else {
      this.workmodel.showflowin = 0;
     
    } 
    if (this.config.emptyrun == true) {
      this.workmodel.emptyrun = 1;
    } else {
      this.workmodel.emptyrun = 0;
    }
    if(this.config.enter==true){
      this.workmodel.enter=1;
      this.key.enter="enter";
    }else{
      this.workmodel.enter=0;
      this.key.enter="";
    }
    if(this.config.up==true){
      this.workmodel.up=1;
      this.key.up="up";
    }else{
      this.workmodel.up=0;
      this.key.up="";
    }
    if(this.config.down==true){
      this.workmodel.down=1;
      this.key.down="down";
    }else{
      this.workmodel.down=0;
      this.key.down="";
    }
    this.ipcService.send("workModel", this.workmodel);
    

  }

  check(){
    this.ipcService.send("checkcorrect", {"checknumber":this.checknumber});//矫正次数
    
  }  
  
  
 ngOnInit() {
 }
}