export class productDetail{
    language:string;
    machinetype:string;
    type:number;
    color:string;
    station:string;
    SN:string;
    key:string[];
    pass:number;
    msg:string
}