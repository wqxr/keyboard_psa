export class Trayinfo{
    language:string;
    machineType:string;
    type:number;
    color:string;
    station:string;
    SN:string;
}