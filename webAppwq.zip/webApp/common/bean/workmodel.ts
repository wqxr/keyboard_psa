export class workModel{
    CCD: number;
    scanCode: number;
    dataUpload: number;
    space: number;
    enableStationA: number;
    enableStationB: number;
    showflowin:number;
    // inkeyboard:number;//keyboard上传
    // trayin:number;//tray盘上传
    emptyrun:number;//空炮
    enter:number;
    up:number;
    down:number;
}