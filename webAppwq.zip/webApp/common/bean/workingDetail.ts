export class workingDetail{
    contory: string;
    model: string;
    area: string;
    color: string;
    EEEE: string;
    config: string
}