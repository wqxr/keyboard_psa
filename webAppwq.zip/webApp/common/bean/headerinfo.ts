export class Headerinfo{
    CT: number;
    finishKeyBoard: number;
    Atraynumber: number;
    Btraynumber: number;
    totalPCBnumber: number;
    Acycletime: number = 0;//A装配周期时间
    Bcycletime: number = 0;//B装配周期时间
    headdetail: number[] = [];
}